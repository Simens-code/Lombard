﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp11
{
    public partial class AddEditItemWindow : Window
    {
        public PledgeItems NewItem { get; private set; }
        private bool isEditMode = false;

        public AddEditItemWindow(PledgeItems item = null)
        {
            InitializeComponent();

            if (item != null)
            {
                isEditMode = true;
                NewItem = item;
                LoadData();
            }
            else
            {
                NewItem = new PledgeItems();
            }
        }

        private void LoadData()
        {
            txtName.Text = NewItem.name;
            txtDescription.Text = NewItem.description;
            txtWeight.Text = NewItem.weight_grams?.ToString();
            txtEstimatedValue.Text = NewItem.estimated_value.ToString();
            txtSerialNumber.Text = NewItem.serial_number;

            // Выбираем состояние
            foreach (ComboBoxItem item in cmbCondition.Items)
            {
                if (item.Content.ToString() == NewItem.condition)
                {
                    cmbCondition.SelectedItem = item;
                    break;
                }
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!decimal.TryParse(txtEstimatedValue.Text, out decimal value) || value <= 0)
            {
                MessageBox.Show("Введите корректную оценочную стоимость", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
                return;

            NewItem.name = txtName.Text.Trim();
            NewItem.description = txtDescription.Text?.Trim();

            if (decimal.TryParse(txtWeight.Text, out decimal weight))
                NewItem.weight_grams = weight;

            NewItem.estimated_value = decimal.Parse(txtEstimatedValue.Text);
            NewItem.serial_number = txtSerialNumber.Text?.Trim();
            NewItem.condition = (cmbCondition.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (!isEditMode)
                NewItem.created_at = DateTime.Now;

            DialogResult = true;
            Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}