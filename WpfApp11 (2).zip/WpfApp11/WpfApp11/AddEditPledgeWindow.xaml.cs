﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Diagnostics;

namespace WpfApp11
{
    public partial class AddEditPledgeWindow : Window
    {
        private KursovayaEntities db;
        private Pledges currentPledge;
        private bool isEditMode = false;
        private List<PledgeItems> items = new List<PledgeItems>();

        public AddEditPledgeWindow(Pledges pledge, KursovayaEntities context)
        {
            InitializeComponent();
            db = context;
            currentPledge = pledge;
            isEditMode = pledge != null;

            InitializeForm();
            LoadData();

            // Обработка гиперссылок
            LoadHyperlinks();
        }

        private void LoadHyperlinks()
        {
            // Находим все гиперссылки и добавляем обработчик
            var hyperlinks = FindVisualChildren<System.Windows.Documents.Hyperlink>(this);
            foreach (var link in hyperlinks)
            {
                link.RequestNavigate += (s, e) =>
                {
                    Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
                    e.Handled = true;
                };
            }
        }

        private IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < System.Windows.Media.VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = System.Windows.Media.VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        private void InitializeForm()
        {
            if (isEditMode)
            {
                txtTitle.Text = "Редактирование залога";
                btnSave.Content = "Обновить";
            }
        }

        private void LoadData()
        {
            try
            {
                // Загружаем клиентов
                cmbClient.ItemsSource = db.Clients.Select(c => new
                {
                    c.id,
                    FullName = c.last_name + " " + c.first_name + " " + (c.middle_name ?? "")
                }).ToList();

                // Загружаем категории
                cmbCategory.ItemsSource = db.PledgeCategories.ToList();

                // Загружаем товары если редактируем
                if (isEditMode && currentPledge != null)
                {
                    txtLoanAmount.Text = currentPledge.loan_amount.ToString();
                    txtInterestRate.Text = currentPledge.interest_rate.ToString();
                    txtStorageCost.Text = currentPledge.storage_cost?.ToString();
                    txtLoanTermDays.Text = currentPledge.loan_term_days?.ToString() ?? "30";

                    // Выбираем клиента
                    foreach (dynamic client in cmbClient.Items)
                    {
                        if (client.id == currentPledge.client_id)
                        {
                            cmbClient.SelectedItem = client;
                            break;
                        }
                    }

                    // Выбираем категорию
                    foreach (var category in cmbCategory.Items)
                    {
                        if ((category as PledgeCategories).id == currentPledge.category_id)
                        {
                            cmbCategory.SelectedItem = category;
                            break;
                        }
                    }

                    // Выбираем статус
                    foreach (ComboBoxItem item in cmbStatus.Items)
                    {
                        if ((string)item.Tag == currentPledge.status)
                        {
                            cmbStatus.SelectedItem = item;
                            break;
                        }
                    }

                    // Загружаем товары
                    items = db.PledgeItems.Where(i => i.pledge_id == currentPledge.id).ToList();
                    dgItems.ItemsSource = items;
                    UpdateTotalValue();
                }
                else
                {
                    cmbStatus.SelectedIndex = 0;
                    txtLoanTermDays.Text = "30";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateTotalValue()
        {
            decimal total = items.Sum(i => i.estimated_value);
            txtTotalEstimatedValue.Text = total.ToString("N0");
            txtTotalValueDisplay.Text = $"{total:N0} ₽";
        }

        private void btnAddItem_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditItemWindow(null);
            if (window.ShowDialog() == true)
            {
                items.Add(window.NewItem);
                dgItems.ItemsSource = null;
                dgItems.ItemsSource = items;
                UpdateTotalValue();
            }
        }

        private void btnEditItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgItems.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар для редактирования", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var selectedItem = dgItems.SelectedItem as PledgeItems;
            var window = new AddEditItemWindow(selectedItem);
            if (window.ShowDialog() == true)
            {
                selectedItem.name = window.NewItem.name;
                selectedItem.description = window.NewItem.description;
                selectedItem.weight_grams = window.NewItem.weight_grams;
                selectedItem.estimated_value = window.NewItem.estimated_value;
                selectedItem.serial_number = window.NewItem.serial_number;
                selectedItem.condition = window.NewItem.condition;

                dgItems.ItemsSource = null;
                dgItems.ItemsSource = items;
                UpdateTotalValue();
            }
        }

        private void btnDeleteItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgItems.SelectedItem == null)
            {
                MessageBox.Show("Выберите товар для удаления", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (MessageBox.Show("Удалить выбранный товар?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                var item = dgItems.SelectedItem as PledgeItems;
                items.Remove(item);
                dgItems.ItemsSource = null;
                dgItems.ItemsSource = items;
                UpdateTotalValue();
            }
        }

        private void btnNewClient_Click(object sender, RoutedEventArgs e)
        {
            var clientWindow = new AddEditClientWindow(null, db);
            if (clientWindow.ShowDialog() == true)
            {
                LoadData();
            }
        }

        private void cmbClient_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        private bool ValidateForm()
        {
            if (cmbClient.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (cmbCategory.SelectedItem == null)
            {
                MessageBox.Show("Выберите категорию", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (items.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы один товар в залог", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!decimal.TryParse(txtLoanAmount.Text, out decimal loanAmount) || loanAmount <= 0)
            {
                MessageBox.Show("Введите корректную сумму займа", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!decimal.TryParse(txtInterestRate.Text, out decimal interestRate) || interestRate <= 0)
            {
                MessageBox.Show("Введите корректную процентную ставку", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!chkTermsAccepted.IsChecked == true || !chkLiabilityAccepted.IsChecked == true)
            {
                MessageBox.Show("Клиент должен ознакомиться и согласиться с правилами ломбарда", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                dynamic selectedClient = cmbClient.SelectedItem;
                var selectedCategory = cmbCategory.SelectedItem as PledgeCategories;
                var selectedStatus = (cmbStatus.SelectedItem as ComboBoxItem).Tag as string;

                if (!isEditMode)
                {
                    currentPledge = new Pledges();
                    currentPledge.created_at = DateTime.Now;
                }

                currentPledge.client_id = selectedClient.id;
                currentPledge.category_id = selectedCategory.id;
                currentPledge.loan_amount = decimal.Parse(txtLoanAmount.Text);
                currentPledge.interest_rate = decimal.Parse(txtInterestRate.Text);
                currentPledge.estimated_value = items.Sum(i => i.estimated_value);

                if (decimal.TryParse(txtStorageCost.Text, out decimal storageCost))
                    currentPledge.storage_cost = storageCost;

                currentPledge.status = selectedStatus;
                currentPledge.loan_term_days = int.Parse(txtLoanTermDays.Text);
                currentPledge.contract_notes = txtContractNotes.Text;

                if (!isEditMode)
                {
                    var assessor = db.Users.FirstOrDefault(u => u.role == "assessor");
                    currentPledge.created_by = assessor?.id ?? 1;
                    db.Pledges.Add(currentPledge);
                    db.SaveChanges();

                    // Сохраняем товары
                    foreach (var item in items)
                    {
                        item.pledge_id = currentPledge.id;
                        item.created_at = DateTime.Now;
                        db.PledgeItems.Add(item);
                    }
                }
                else
                {
                    // Обновляем существующие товары
                    var existingItems = db.PledgeItems.Where(i => i.pledge_id == currentPledge.id).ToList();
                    foreach (var existingItem in existingItems)
                    {
                        db.PledgeItems.Remove(existingItem);
                    }

                    foreach (var item in items)
                    {
                        item.pledge_id = currentPledge.id;
                        item.created_at = DateTime.Now;
                        db.PledgeItems.Add(item);
                    }
                }

                db.SaveChanges();

                MessageBox.Show($"Залог успешно сохранен!\n\n" +
                    $"Клиент: {selectedClient.FullName}\n" +
                    $"Количество товаров: {items.Count}\n" +
                    $"Общая оценка: {currentPledge.estimated_value:N0} ₽\n" +
                    $"Сумма займа: {currentPledge.loan_amount:N0} ₽\n" +
                    $"Срок займа: {currentPledge.loan_term_days} дней",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}\n\nДетали: {ex.InnerException?.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}