﻿using System;

namespace WpfApp11
{
    // Частичный класс для расширения автоматически сгенерированного класса Pledges
    public partial class Pledges
    {
        // Вычисляемое свойство - осталось дней
        public int? DaysRemaining
        {
            get
            {
                if (created_at.HasValue && loan_term_days.HasValue && loan_term_days.Value > 0)
                {
                    var expirationDate = created_at.Value.AddDays(loan_term_days.Value);
                    var daysLeft = (expirationDate - DateTime.Today).Days;
                    return daysLeft > 0 ? daysLeft : 0;
                }
                return null;
            }
        }

        // Вычисляемое свойство - дата истечения срока
        public DateTime? ExpirationDate
        {
            get
            {
                if (created_at.HasValue && loan_term_days.HasValue && loan_term_days.Value > 0)
                    return created_at.Value.AddDays(loan_term_days.Value);
                return null;
            }
        }
    }
}