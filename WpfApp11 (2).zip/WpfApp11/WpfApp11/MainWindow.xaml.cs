﻿using System.Linq;
using System.Windows;

namespace WpfApp11
{
    public partial class MainWindow : Window
    {
        private KursovayaEntities db;

        public MainWindow()
        {
            InitializeComponent();
            txtLogin.Focus();
            db = new KursovayaEntities();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var user = db.Users.FirstOrDefault(u => u.login == username && u.password_hash == password);

            if (user != null)
            {
                var mainWindow = new PawnShopWindow(user);
                mainWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }
    }
}