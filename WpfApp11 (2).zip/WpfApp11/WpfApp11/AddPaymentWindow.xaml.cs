﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;

namespace WpfApp11
{
    public partial class AddPaymentWindow : Window
    {
        private KursovayaEntities db;
        private Contracts selectedContract;

        public AddPaymentWindow(KursovayaEntities context)
        {
            InitializeComponent();
            db = context;
            LoadContracts();

            cmbContract.SelectionChanged += CmbContract_SelectionChanged;
        }

        private void LoadContracts()
        {
            try
            {
                var contracts = db.Contracts
                    .Where(c => c.is_active == true)
                    .OrderByDescending(c => c.start_date)
                    .ToList();

                cmbContract.ItemsSource = contracts;
                if (contracts.Any())
                {
                    cmbContract.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки договоров: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CmbContract_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbContract.SelectedItem is Contracts contract)
            {
                selectedContract = contract;
                UpdateContractInfo(contract);
            }
        }

        private void UpdateContractInfo(Contracts contract)
        {
            try
            {
                // Получаем информацию о залоге и клиенте через навигационные свойства
                var pledge = db.Pledges
                    .Include(p => p.Clients) // загружаем связанного клиента
                    .FirstOrDefault(p => p.id == contract.pledge_id);

                if (pledge != null && pledge.Clients != null)
                {
                    var client = pledge.Clients;

                    // Информация о клиенте
                    txtClientInfo.Text = $"{client.last_name} {client.first_name} {client.middle_name}\n" +
                                        $"Телефон: {client.phone}\n" +
                                        $"Паспорт: {client.passport_series} {client.passport_number}";
                    borderClientInfo.Visibility = Visibility.Visible;

                    // Информация о залоге
                    txtPledgeInfo.Text = $"{pledge.name}\n" +
                                        $"Сумма займа: {pledge.loan_amount:N0} ₽\n" +
                                        $"Процентная ставка: {pledge.interest_rate}%\n" +
                                        $"Остаток: {GetRemainingAmount(contract, pledge)} ₽";
                    borderPledgeInfo.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при загрузке информации: {ex.Message}");
                // Скрываем информационные блоки при ошибке
                borderClientInfo.Visibility = Visibility.Collapsed;
                borderPledgeInfo.Visibility = Visibility.Collapsed;
            }
        }

        private decimal GetRemainingAmount(Contracts contract, Pledges pledge)
        {
            try
            {
                var totalPaid = db.Payments
                    .Where(p => p.contract_id == contract.id &&
                               (p.payment_type == "loan_repayment" || p.payment_type == "additional"))
                    .Sum(p => (decimal?)p.amount) ?? 0;

                return pledge.loan_amount - totalPaid;
            }
            catch
            {
                return pledge.loan_amount;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                var contract = (Contracts)cmbContract.SelectedItem;
                var paymentType = ((ComboBoxItem)cmbPaymentType.SelectedItem).Tag.ToString();
                var paymentMethod = ((ComboBoxItem)cmbPaymentMethod.SelectedItem).Tag.ToString();

                var payment = new Payments
                {
                    contract_id = contract.id,
                    amount = decimal.Parse(txtAmount.Text),
                    payment_type = paymentType,
                    payment_method = paymentMethod,
                    // Убрали notes, так как его нет в таблице
                    received_by = GetCurrentCashierId(),
                    created_at = DateTime.Now
                };

                db.Payments.Add(payment);
                db.SaveChanges();

                MessageBox.Show($"Платеж на сумму {payment.amount:N0} ₽ успешно добавлен!",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}\n\nДетали: {ex.InnerException?.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateForm()
        {
            // Основная валидация
            if (cmbContract.SelectedItem == null)
            {
                MessageBox.Show("Выберите договор", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtAmount.Text))
            {
                MessageBox.Show("Введите сумму платежа", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                txtAmount.Focus();
                return false;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount) || amount <= 0)
            {
                MessageBox.Show("Введите корректную сумму (положительное число)", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                txtAmount.SelectAll();
                txtAmount.Focus();
                return false;
            }

            return true;
        }

        private int GetCurrentCashierId()
        {
            try
            {
                // Получаем ID кассира из текущего пользователя
                // В реальном приложении это должно браться из контекста
                var cashier = db.Users.FirstOrDefault(u => u.role == "cashier");
                return cashier?.id ?? 3; // По умолчанию ID=3 (кассир из вашей таблицы)
            }
            catch
            {
                return 3; // Fallback ID
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}