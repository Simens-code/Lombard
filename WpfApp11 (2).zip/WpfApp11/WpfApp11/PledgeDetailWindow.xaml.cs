﻿using System;
using System.Linq;
using System.Windows;

namespace WpfApp11
{
    public partial class PledgeDetailWindow : Window
    {
        public PledgeDetailWindow(Pledges pledge, KursovayaEntities db)
        {
            InitializeComponent();
            LoadPledgeDetails(pledge, db);
        }

        private void LoadPledgeDetails(Pledges pledge, KursovayaEntities db)
        {
            try
            {
                var client = db.Clients.Find(pledge.client_id);
                var category = db.PledgeCategories.Find(pledge.category_id);
                var createdBy = db.Users.Find(pledge.created_by);

                txtId.Text = $"ID: {pledge.id}";
                txtName.Text = pledge.name;
                txtDescription.Text = pledge.description ?? "Описание отсутствует";
                txtClient.Text = client != null ?
                    $"Клиент: {client.last_name} {client.first_name} {client.middle_name}\n" +
                    $"Телефон: {client.phone}\n" +
                    $"Паспорт: {client.passport_series} {client.passport_number}"
                    : "Клиент не найден";
                txtCategory.Text = $"Категория: {category?.name ?? "Не указана"}";
                txtWeight.Text = pledge.weight_grams.HasValue ?
                    $"Вес: {pledge.weight_grams} г" : "Вес: не указан";
                txtEstimatedValue.Text = $"{pledge.estimated_value:N0} ₽";
                txtLoanAmount.Text = $"{pledge.loan_amount:N0} ₽";
                txtInterestRate.Text = $"{pledge.interest_rate:N2}%";
                txtStorageCost.Text = pledge.storage_cost.HasValue ?
                    $"{pledge.storage_cost:N0} ₽" : "Не указана";
                txtStatus.Text = MapStatus(pledge.status);
                txtCreatedBy.Text = createdBy != null ?
                    $"{createdBy.last_name} {createdBy.first_name}" : "Неизвестно";
                txtCreatedAt.Text = pledge.created_at?.ToString("dd.MM.yyyy HH:mm") ?? "Не указана";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки деталей: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string MapStatus(string status)
        {
            switch (status)
            {
                case "accepted": return "Принят";
                case "in_storage": return "На складе";
                case "redeemed": return "Выкуплен";
                case "sold": return "Продан";
                default: return status;
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}