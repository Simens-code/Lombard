﻿using System;
using System.Linq;
using System.Windows;

namespace WpfApp11
{
    public partial class AddEditClientWindow : Window
    {
        private KursovayaEntities db;
        private Clients currentClient;
        private bool isEditMode = false;

        public AddEditClientWindow(Clients client, KursovayaEntities context)
        {
            InitializeComponent();
            db = context;
            currentClient = client;
            isEditMode = client != null;

            InitializeForm();
            LoadData();
        }

        private void InitializeForm()
        {
            if (isEditMode)
            {
                txtTitle.Text = "Редактирование клиента";
                btnSave.Content = "Обновить";
            }
        }

        private void LoadData()
        {
            try
            {
                // Если редактируем, заполняем поля
                if (isEditMode && currentClient != null)
                {
                    txtLastName.Text = currentClient.last_name;
                    txtFirstName.Text = currentClient.first_name;
                    txtMiddleName.Text = currentClient.middle_name;
                    txtPassportSeries.Text = currentClient.passport_series;
                    txtPassportNumber.Text = currentClient.passport_number;
                    txtIssuedBy.Text = currentClient.issued_by;

                    if (currentClient.issue_date.HasValue)
                        dpIssueDate.SelectedDate = currentClient.issue_date.Value;

                    txtPhone.Text = currentClient.phone;
                    txtEmail.Text = currentClient.email;
                    txtAddress.Text = currentClient.address;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("Введите фамилию клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("Введите имя клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPassportSeries.Text) || txtPassportSeries.Text.Length != 4)
            {
                MessageBox.Show("Серия паспорта должна содержать 4 цифры", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPassportNumber.Text) || txtPassportNumber.Text.Length != 6)
            {
                MessageBox.Show("Номер паспорта должен содержать 6 цифр", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Введите телефон клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            // Проверка на уникальность паспортных данных (только для нового клиента)
            if (!isEditMode)
            {
                bool passportExists = db.Clients.Any(c =>
                    c.passport_series == txtPassportSeries.Text &&
                    c.passport_number == txtPassportNumber.Text);

                if (passportExists)
                {
                    MessageBox.Show("Клиент с такими паспортными данными уже существует", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }

            return true;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                if (!isEditMode)
                {
                    currentClient = new Clients();
                    currentClient.created_at = DateTime.Now;
                }

                // Заполняем поля
                currentClient.last_name = txtLastName.Text.Trim();
                currentClient.first_name = txtFirstName.Text.Trim();
                currentClient.middle_name = txtMiddleName.Text?.Trim();
                currentClient.passport_series = txtPassportSeries.Text.Trim();
                currentClient.passport_number = txtPassportNumber.Text.Trim();
                currentClient.issued_by = txtIssuedBy.Text?.Trim();
                currentClient.issue_date = dpIssueDate.SelectedDate;
                currentClient.phone = txtPhone.Text.Trim();
                currentClient.email = txtEmail.Text?.Trim();
                currentClient.address = txtAddress.Text?.Trim();

                if (!isEditMode)
                {
                    db.Clients.Add(currentClient);
                }

                db.SaveChanges();
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}\n\nДетали: {ex.InnerException?.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}