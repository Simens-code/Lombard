﻿using System;
using System.Windows;
using System.Text;
using System.IO;

namespace WpfApp11
{
    public partial class ReceiptWindow : Window
    {
        public ReceiptWindow()
        {
            InitializeComponent();
        }

        public void GenerateReceipt(dynamic data)
        {
            var sb = new StringBuilder();

            sb.AppendLine("╔════════════════════════════════════════════╗");
            sb.AppendLine("║              ЛОМБАРД СОФТ                 ║");
            sb.AppendLine("║                КВИТАНЦИЯ                  ║");
            sb.AppendLine("╠════════════════════════════════════════════╣");
            sb.AppendLine($"║ №: {data.ReceiptNumber,-36}║");
            sb.AppendLine($"║ Дата: {DateTime.Now:dd.MM.yyyy HH:mm}                     ║");
            sb.AppendLine($"║ Сотрудник: {data.CashierName,-32}║");
            sb.AppendLine("╠════════════════════════════════════════════╣");
            sb.AppendLine("║ КЛИЕНТ:                                    ║");
            sb.AppendLine($"║ {data.ClientName,-40}║");
            sb.AppendLine("╠════════════════════════════════════════════╣");
            sb.AppendLine("║ ТОВАРЫ В ЗАЛОГЕ:                           ║");

            foreach (var item in data.Items)
            {
                string itemName = item.name.Length > 36 ? item.name.Substring(0, 33) + "..." : item.name;
                sb.AppendLine($"║ • {itemName,-38}║");
                sb.AppendLine($"║   {item.estimated_value:N0} ₽                        ║");
            }

            sb.AppendLine("╠════════════════════════════════════════════╣");
            sb.AppendLine($"║ Общая оценка: {data.TotalEstimatedValue,28:N0} ₽ ║");
            sb.AppendLine($"║ Сумма займа:  {data.LoanAmount,28:N0} ₽ ║");
            sb.AppendLine($"║ Процент:      {data.InterestRate,28}% ║");
            sb.AppendLine($"║ Срок займа:   {data.LoanTermDays,28} дн. ║");
            sb.AppendLine("╠════════════════════════════════════════════╣");
            sb.AppendLine($"║ Сумма к выдаче: {data.LoanAmount,24:N0} ₽ ║");
            sb.AppendLine("╚════════════════════════════════════════════╝");
            sb.AppendLine();
            sb.AppendLine("   С условиями займа ознакомлен(а):");
            sb.AppendLine();
            sb.AppendLine("   ______________________ (подпись)");
            sb.AppendLine();
            sb.AppendLine("   М.П.            ______________________");
            sb.AppendLine();
            sb.AppendLine("   ⚖️ В случае невыплаты займа в указанный срок,");
            sb.AppendLine("      залоговое имущество переходит в собственность");
            sb.AppendLine("      ломбарда (ст. 358.8 Гражданского кодекса РФ)");

            txtReceipt.Text = sb.ToString();
        }

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string fileName = $"Квитанция_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
                string filePath = Path.Combine(desktopPath, fileName);
                File.WriteAllText(filePath, txtReceipt.Text, Encoding.UTF8);

                MessageBox.Show($"Квитанция сохранена на рабочий стол:\n{fileName}", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}