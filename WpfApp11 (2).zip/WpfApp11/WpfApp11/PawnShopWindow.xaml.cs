﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.IO;
using System.Collections.Generic;

namespace WpfApp11
{
    public partial class PawnShopWindow : Window
    {
        private KursovayaEntities db = new KursovayaEntities();
        private Users currentUser;

        // Добавьте эти поля в класс PawnShopWindow
        private List<dynamic> allPledgesData;
        private List<dynamic> allClientsData;
        private List<dynamic> allContractsData;
        private List<dynamic> allPaymentsData;

        public PawnShopWindow(Users user)
        {
            InitializeComponent();
            currentUser = user;
            txtWelcome.Text = $"Добро пожаловать, {user.first_name} {user.last_name} ({user.role})";

            // Установка дат для отчетов
            dpReportStart.SelectedDate = DateTime.Today;
            dpReportEnd.SelectedDate = DateTime.Today;

            LoadAllData();
        }

        private void LoadAllData()
        {
            try
            {
                var clients = db.Clients.ToList();
                var categories = db.PledgeCategories.ToList();
                var pledges = db.Pledges.ToList();
                var contracts = db.Contracts.ToList();
                var users = db.Users.ToList();
                var payments = db.Payments.ToList();
                var items = db.PledgeItems.ToList();

                // Расчет оставшихся дней и остатка для каждого залога
                foreach (var pledge in pledges)
                {
                    // Расчет остатка по займу
                    var paidAmount = payments
                        .Where(p =>
                        {
                            var contract = contracts.FirstOrDefault(c => c.id == p.contract_id);
                            return contract != null && contract.pledge_id == pledge.id &&
                                   (p.payment_type == "loan_repayment" || p.payment_type == "additional");
                        })
                        .Sum(p => (decimal?)p.amount) ?? 0;
                    pledge.remaining_amount = pledge.loan_amount - paidAmount;
                }

                // 1. Таблица залогов с дополнительной информацией
                allPledgesData = pledges.Select(p => new
                {
                    p.id,
                    p.name,
                    ClientFullName = GetClientName(p.client_id, clients),
                    CategoryName = GetCategoryName(p.category_id, categories),
                    p.estimated_value,
                    p.loan_amount,
                    RemainingAmount = p.remaining_amount,
                    Status = GetStatusText(p.status),
                    p.created_at,
                    DaysRemaining = CalculateDaysRemaining(p.created_at, p.loan_term_days),
                    ExpirationDate = CalculateExpirationDate(p.created_at, p.loan_term_days),
                    LoanTermDays = p.loan_term_days
                }).ToList<dynamic>();

                dgPledges.ItemsSource = allPledgesData;

                // 2. Таблица клиентов
                allClientsData = clients.Select(c => new
                {
                    c.id,
                    c.last_name,
                    c.first_name,
                    c.phone,
                    Passport = c.passport_series + " " + c.passport_number,
                    c.email,
                    c.created_at
                }).ToList<dynamic>();
                dgClients.ItemsSource = allClientsData;

                // 3. Таблица договоров
                allContractsData = contracts.Select(c => new
                {
                    c.id,
                    c.contract_number,
                    PledgeName = GetPledgeName(c.pledge_id, pledges),
                    c.start_date,
                    c.end_date,
                    c.total_amount,
                    Status = c.is_active == true ? "Активен" : "Завершен"
                }).ToList<dynamic>();
                dgContracts.ItemsSource = allContractsData;

                // 4. Таблица платежей
                allPaymentsData = payments.Select(p => new
                {
                    p.id,
                    ContractNumber = GetContractNumber(p.contract_id, contracts),
                    p.amount,
                    PaymentType = GetPaymentTypeText(p.payment_type),
                    p.payment_method,
                    ReceivedBy = GetUserName(p.received_by, users),
                    p.created_at
                }).ToList<dynamic>();
                dgPayments.ItemsSource = allPaymentsData;

                // 5. Обновить статистику
                UpdateStatistics(pledges, clients, payments);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Вспомогательные методы для расчета
        private int? CalculateDaysRemaining(DateTime? createdDate, int? loanTermDays)
        {
            if (createdDate.HasValue && loanTermDays.HasValue)
            {
                var expirationDate = createdDate.Value.AddDays(loanTermDays.Value);
                var daysLeft = (expirationDate - DateTime.Today).Days;
                return daysLeft > 0 ? daysLeft : 0;
            }
            return null;
        }

        private DateTime? CalculateExpirationDate(DateTime? createdDate, int? loanTermDays)
        {
            if (createdDate.HasValue && loanTermDays.HasValue)
            {
                return createdDate.Value.AddDays(loanTermDays.Value);
            }
            return null;
        }

        // Вспомогательные методы для получения имен
        private string GetClientName(int clientId, List<Clients> clients)
        {
            var client = clients.FirstOrDefault(c => c.id == clientId);
            return client != null ? $"{client.last_name} {client.first_name}" : "Клиент не найден";
        }

        private string GetCategoryName(int categoryId, List<PledgeCategories> categories)
        {
            var category = categories.FirstOrDefault(c => c.id == categoryId);
            return category?.name ?? "Без категории";
        }

        private string GetPledgeName(int pledgeId, List<Pledges> pledges)
        {
            var pledge = pledges.FirstOrDefault(p => p.id == pledgeId);
            return pledge?.name ?? "Залог не найден";
        }

        private string GetContractNumber(int contractId, List<Contracts> contracts)
        {
            var contract = contracts.FirstOrDefault(c => c.id == contractId);
            return contract?.contract_number ?? "Договор не найден";
        }

        private string GetUserName(int userId, List<Users> users)
        {
            var user = users.FirstOrDefault(u => u.id == userId);
            return user != null ? $"{user.last_name} {user.first_name}" : "Неизвестно";
        }

        // Методы преобразования текста
        private string GetStatusText(string status)
        {
            if (string.IsNullOrEmpty(status)) return "Неизвестно";

            switch (status.ToLower())
            {
                case "accepted": return "Принят";
                case "in_storage": return "На складе";
                case "redeemed": return "Выкуплен";
                case "sold": return "Продан";
                default: return status;
            }
        }

        private string GetPaymentTypeText(string paymentType)
        {
            if (string.IsNullOrEmpty(paymentType)) return "Неизвестно";

            switch (paymentType.ToLower())
            {
                case "loan_repayment": return "Погашение займа";
                case "interest": return "Проценты";
                case "storage": return "Хранение";
                case "additional": return "Дополнительный взнос";
                default: return paymentType;
            }
        }

        // Обновление статистики
        private void UpdateStatistics(List<Pledges> pledges, List<Clients> clients, List<Payments> payments)
        {
            try
            {
                var totalLoans = pledges.Sum(p => p.loan_amount);
                var activePledges = pledges.Count(p => p.status == "in_storage" || p.status == "accepted");
                var totalClients = clients.Count;
                var todayPayments = payments
                    .Where(p => p.created_at.HasValue && p.created_at.Value.Date == DateTime.Today)
                    .Sum(p => (decimal?)p.amount) ?? 0;

                txtStatsTotalLoans.Text = $"Общая сумма займов: {totalLoans:N0} ₽";
                txtStatsActivePledges.Text = $"Активных залогов: {activePledges}";
                txtStatsTotalClients.Text = $"Всего клиентов: {totalClients}";
                txtStatsTodayPayments.Text = $"Платежи сегодня: {todayPayments:N0} ₽";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка статистики: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- МЕТОДЫ ПОИСКА, ФИЛЬТРАЦИИ И СОРТИРОВКИ ---

        private void txtSearchPledge_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterPledges();
        }

        private void cmbStatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterPledges();
        }

        private void cmbSortBy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterPledges();
        }

        private void FilterPledges()
        {
            if (allPledgesData == null) return;

            var filtered = allPledgesData.AsEnumerable();

            // Поиск по тексту
            string searchText = txtSearchPledge.Text?.ToLower() ?? "";
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                filtered = filtered.Where(p =>
                {
                    string name = p.GetType().GetProperty("name")?.GetValue(p, null)?.ToString()?.ToLower() ?? "";
                    string clientName = p.GetType().GetProperty("ClientFullName")?.GetValue(p, null)?.ToString()?.ToLower() ?? "";
                    return name.Contains(searchText) || clientName.Contains(searchText);
                });
            }

            // Фильтр по статусу
            var selectedStatusItem = cmbStatusFilter.SelectedItem as ComboBoxItem;
            if (selectedStatusItem != null)
            {
                string selectedStatus = selectedStatusItem.Content.ToString();
                if (selectedStatus != "Все статусы")
                {
                    filtered = filtered.Where(p =>
                    {
                        string status = p.GetType().GetProperty("Status")?.GetValue(p, null)?.ToString() ?? "";
                        return status == selectedStatus;
                    });
                }
            }

            // Сортировка
            var sortByItem = cmbSortBy.SelectedItem as ComboBoxItem;
            if (sortByItem != null)
            {
                string sortBy = sortByItem.Content.ToString();
                switch (sortBy)
                {
                    case "По дате (новые)":
                        filtered = filtered.OrderByDescending(p => p.GetType().GetProperty("created_at")?.GetValue(p, null));
                        break;
                    case "По дате (старые)":
                        filtered = filtered.OrderBy(p => p.GetType().GetProperty("created_at")?.GetValue(p, null));
                        break;
                    case "По сумме займа (возр.)":
                        filtered = filtered.OrderBy(p => p.GetType().GetProperty("loan_amount")?.GetValue(p, null));
                        break;
                    case "По сумме займа (убыв.)":
                        filtered = filtered.OrderByDescending(p => p.GetType().GetProperty("loan_amount")?.GetValue(p, null));
                        break;
                    case "По сроку (скоро заканчивается)":
                        filtered = filtered.OrderBy(p => p.GetType().GetProperty("DaysRemaining")?.GetValue(p, null) ?? 999);
                        break;
                }
            }

            dgPledges.ItemsSource = filtered.ToList();
        }

        // --- ПЕЧАТЬ ЧЕКА ---

        private void btnPrintCheck_Click(object sender, RoutedEventArgs e)
        {
            if (dgPledges.SelectedItem == null)
            {
                MessageBox.Show("Выберите залог для печати квитанции", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                dynamic selectedItem = dgPledges.SelectedItem;
                int pledgeId = selectedItem.id;

                var pledge = db.Pledges.Find(pledgeId);
                if (pledge == null)
                {
                    MessageBox.Show("Залог не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var client = db.Clients.Find(pledge.client_id);
                var items = db.PledgeItems.Where(i => i.pledge_id == pledgeId).ToList();

                var receiptData = new
                {
                    ReceiptNumber = $"ЗПГ-{pledgeId:00000}",
                    CashierName = $"{currentUser.last_name} {currentUser.first_name}",
                    ClientName = client != null ? $"{client.last_name} {client.first_name} {client.middle_name}" : "Клиент не найден",
                    Items = items,
                    TotalEstimatedValue = items.Sum(i => i.estimated_value),
                    LoanAmount = pledge.loan_amount,
                    InterestRate = pledge.interest_rate,
                    LoanTermDays = pledge.loan_term_days ?? 30
                };

                var receiptWindow = new ReceiptWindow();
                receiptWindow.GenerateReceipt(receiptData);
                receiptWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании квитанции: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- СОЗДАНИЕ ОТЧЕТА ---

        private void btnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (dpReportStart.SelectedDate == null || dpReportEnd.SelectedDate == null)
            {
                MessageBox.Show("Выберите период для отчета", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var startDate = dpReportStart.SelectedDate.Value;
            var endDate = dpReportEnd.SelectedDate.Value;
            var reportTypeItem = cmbReportType.SelectedItem as ComboBoxItem;

            if (reportTypeItem == null)
            {
                MessageBox.Show("Выберите тип отчета", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string reportText = CreateSimpleReport(startDate, endDate, reportTypeItem.Content.ToString());
                SaveReportToFile(reportText, startDate, endDate, reportTypeItem.Content.ToString());

                MessageBox.Show(reportText, "Отчет создан",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания отчета: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string CreateSimpleReport(DateTime startDate, DateTime endDate, string reportType)
        {
            var allPledges = db.Pledges.ToList();
            var allClients = db.Clients.ToList();
            var allPayments = db.Payments.ToList();
            var allContracts = db.Contracts.ToList();

            var report = $"=== ОТЧЕТ: {reportType} ===\n" +
                        $"Период: {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}\n" +
                        $"Создан: {DateTime.Now:dd.MM.yyyy HH:mm}\n" +
                        $"Сотрудник: {currentUser.last_name} {currentUser.first_name}\n\n";

            report += "СТАТИСТИКА:\n";
            report += $"• Залогов в периоде: {allPledges.Count(p => p.created_at >= startDate && p.created_at <= endDate)}\n";
            report += $"• Новых клиентов: {allClients.Count(c => c.created_at >= startDate && c.created_at <= endDate)}\n";
            report += $"• Сумма займов: {allPledges.Where(p => p.created_at >= startDate && p.created_at <= endDate).Sum(p => p.loan_amount):N0} ₽\n";
            report += $"• Платежей: {allPayments.Count(p => p.created_at >= startDate && p.created_at <= endDate)}\n";
            report += $"• Сумма платежей: {allPayments.Where(p => p.created_at >= startDate && p.created_at <= endDate).Sum(p => p.amount):N0} ₽\n";

            return report;
        }

        private void SaveReportToFile(string reportText, DateTime startDate, DateTime endDate, string reportType)
        {
            try
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string fileName = $"Отчет_{reportType}_{DateTime.Now:yyyy-MM-dd_HH-mm}.txt";
                string filePath = Path.Combine(desktopPath, fileName);

                File.WriteAllText(filePath, reportText);

                MessageBox.Show($"Отчет сохранен на рабочий стол:\n{fileName}",
                    "Отчет сохранен", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch { }
        }

        // --- КНОПКИ ОБНОВЛЕНИЯ ---

        private void btnRefreshPledges_Click(object sender, RoutedEventArgs e) => LoadAllData();
        private void btnRefreshClients_Click(object sender, RoutedEventArgs e) => LoadAllData();
        private void btnRefreshContracts_Click(object sender, RoutedEventArgs e) => LoadAllData();
        private void btnRefreshPayments_Click(object sender, RoutedEventArgs e) => LoadAllData();

        // --- КНОПКИ ДОБАВЛЕНИЯ ---

        private void btnAddPledge_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditPledgeWindow(null, db);
            if (window.ShowDialog() == true) LoadAllData();
        }

        private void btnAddClient_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddEditClientWindow(null, db);
            if (window.ShowDialog() == true) LoadAllData();
        }

        private void btnAddPayment_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddPaymentWindow(db);
            if (window.ShowDialog() == true) LoadAllData();
        }

        // --- КНОПКИ РЕДАКТИРОВАНИЯ ЗАЛОГОВ ---

        private void btnEditPledge_Click(object sender, RoutedEventArgs e)
        {
            if (dgPledges.SelectedItem == null)
            {
                MessageBox.Show("Выберите залог для редактирования", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                dynamic selectedItem = dgPledges.SelectedItem;
                int pledgeId = selectedItem.id;

                var pledge = db.Pledges.Find(pledgeId);
                if (pledge != null)
                {
                    var window = new AddEditPledgeWindow(pledge, db);
                    if (window.ShowDialog() == true)
                    {
                        LoadAllData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- КНОПКИ УДАЛЕНИЯ ЗАЛОГОВ ---

        private void btnDeletePledge_Click(object sender, RoutedEventArgs e)
        {
            if (dgPledges.SelectedItem == null)
            {
                MessageBox.Show("Выберите залог для удаления", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                dynamic selectedItem = dgPledges.SelectedItem;
                int pledgeId = selectedItem.id;

                var pledge = db.Pledges.Find(pledgeId);
                if (pledge != null)
                {
                    var result = MessageBox.Show($"Удалить залог '{pledge.name}'?", "Подтверждение",
                        MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        // Сначала удаляем связанные товары
                        var items = db.PledgeItems.Where(i => i.pledge_id == pledge.id).ToList();
                        foreach (var item in items)
                        {
                            db.PledgeItems.Remove(item);
                        }

                        // Затем удаляем сам залог
                        db.Pledges.Remove(pledge);
                        db.SaveChanges();
                        LoadAllData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- КНОПКИ РЕДАКТИРОВАНИЯ КЛИЕНТОВ ---

        private void btnEditClient_Click(object sender, RoutedEventArgs e)
        {
            if (dgClients.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента для редактирования", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                dynamic selectedItem = dgClients.SelectedItem;
                int clientId = selectedItem.id;

                var client = db.Clients.Find(clientId);
                if (client != null)
                {
                    var window = new AddEditClientWindow(client, db);
                    if (window.ShowDialog() == true)
                    {
                        LoadAllData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- КНОПКИ УДАЛЕНИЯ КЛИЕНТОВ ---

        private void btnDeleteClient_Click(object sender, RoutedEventArgs e)
        {
            if (dgClients.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента для удаления", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                dynamic selectedItem = dgClients.SelectedItem;
                int clientId = selectedItem.id;

                var client = db.Clients.Find(clientId);
                if (client != null)
                {
                    var hasPledges = db.Pledges.Any(p => p.client_id == client.id);
                    if (hasPledges)
                    {
                        MessageBox.Show("Нельзя удалить клиента с активными залогами", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    var result = MessageBox.Show($"Удалить клиента '{client.last_name} {client.first_name}'?", "Подтверждение",
                        MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        db.Clients.Remove(client);
                        db.SaveChanges();
                        LoadAllData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // --- ВЫХОД ---

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Выйти из системы?", "Выход",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }
    }
}